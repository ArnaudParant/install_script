(* $Id: qclient_main.ml 289 2006-04-30 17:50:29Z gerd $ *)

(* Rpc_client.verbose true; *)
Qclient.main() ;;
