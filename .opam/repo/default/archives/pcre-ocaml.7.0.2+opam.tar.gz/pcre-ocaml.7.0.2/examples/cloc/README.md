This program reads C-sources from stdin and prints them to stdout with
comments and empty lines removed. - A very primitive way of counting LOCs.
